# AI Street Brand — Quick Launcher

3단계로 **스트릿 브랜드 생성 플로우**를 빠르게 실행하는 1페이지 런처입니다.

> 1) 셀프 인터뷰 → 2) 네이밍 → 3) 디자인(캔바 연동 GPT)

---

## 📦 구성
- `index.html` — 1페이지 런처 (링크/진행률/잠금 로직 포함)
- `README.md` — 본 문서
- *(선택)* `netlify.toml` — Netlify 드래그&드롭/깃 연동 배포용

---

## 🚀 사용법
1. **링크 확인**: `index.html`에 아래 3개의 링크가 포함되어 있습니다.
   - 셀프 인터뷰하기: `https://chatgpt.com/g/g-688f8fa2d8888191a118d465e1ad388f-self-interviewer`
   - 네이밍 생성하기: `https://chatgpt.com/g/g-xSKJTIgii-ownstreet?model=gpt-4o`
   - 디자인하기(캔바 연동 GPT): `https://chatgpt.com/g/g-alKfVrz9K-canva`

   필요 시 해당 URL만 교체하면 됩니다.

2. **로컬에서 열어보기**: 파일을 더블클릭하여 브라우저에서 열면 즉시 작동합니다.

3. **진행 상태**: 각 단계 버튼을 누르면 새 탭이 열리고, 해당 단계가 **완료 처리**되어 다음 단계가 활성화됩니다.
   - 진행률과 상태는 브라우저 `localStorage`에 저장됩니다.
   - 우측 상단 **초기화** 버튼으로 상태를 리셋할 수 있습니다.

---

## ☁️ 배포 방법
### A) GitHub Pages (간단)
1. GitHub 새 리포지토리 생성: `street-brand-launcher`
2. `index.html`과 `README.md` 업로드 → Commit
3. **Settings → Pages**에서 **Deploy from a branch** / **main (root)** 선택
4. 배포 URL 예: `https://<username>.github.io/street-brand-launcher/`

### B) Netlify (드래그&드롭)
1. Netlify 로그인 → **Add new site → Deploy manually**
2. 폴더 또는 ZIP(`street-brand-launcher.zip`)을 드래그해 업로드
3. 기본 URL 예: `https://<random-name>.netlify.app`
4. 커스텀 도메인은 **Domain management**에서 연결

> `netlify.toml` 예시
```
[build]
  publish = "."
[[redirects]]
  from = "/"
  to = "/index.html"
  status = 200
```

---

## 🧩 커스터마이즈 팁
- **카피/설명 수정**: `index.html`의 텍스트만 바로 편집
- **브랜딩 색상**: 스타일 변수 수정
  ```css
  :root{
    --bg:#0b0b0b;--card:#141414;--ink:#f0f0f0;--muted:#a6a6a6;--accent:#98f5e1;--ok:#58d38c;
  }
  ```
- **순서 잠금 유지**: 링크만 교체해도 1→2→3 잠금 로직은 그대로 동작
- **모바일 대응**: 360px 이상 화면에서 가독성 보장

---

## 🔒 주의/면책
- 연결된 ChatGPTs/Canva 템플릿은 각 서비스 정책을 따릅니다.
- 자동 생성 결과는 상표/저작권 고유성을 보장하지 않으므로, 상업 사용 전 **법적 검토**를 권장합니다.
- 개인정보는 브라우저 저장소(localStorage)만 사용하며, 서버로 전송하지 않습니다.

---

## 📞 문의/피드백
- 개선 아이디어나 버그는 이 리포지토리의 **Issues**로 남겨주세요.
- 템플릿 확장(Wordmark Studio / Brand Kit One‑Pager 등) 요청 시 추가 파일 제공 가능합니다.
